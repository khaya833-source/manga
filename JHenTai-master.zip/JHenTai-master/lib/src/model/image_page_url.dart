class ImagePageUrl {}
