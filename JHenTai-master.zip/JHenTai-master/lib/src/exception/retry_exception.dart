class RetryException implements Exception {}
